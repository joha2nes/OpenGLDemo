2016-07-21

Project participants: Johannes Westberg

Instructions for each demo scene:
	- Demo 1: use WASD-keys to move the camera and use the mouse while holding right button to rotate the camera. Press Escape to show/hide pause menu.
	- Demo 2: use WASD-/arrow-keys to control the camera. Press Escape to show/hide pause menu.
